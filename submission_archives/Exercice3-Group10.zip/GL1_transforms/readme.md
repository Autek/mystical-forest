# Solution Description

To solve these exercises we first chose to split them into 3 equivalent parts.
At first one of us woked early in the week to finish the first part.
It took some time to get used to the template and the tutorial,
then the tasks where done without issues.
Later one of the group did the middle part of the tasks.
Once again, getting used to the template and tuto took some time,
in the end the task was more or less straightforward.
And finally the last person of the group did his part in a similar fashion to the others.
Overall everything was done and most of the work was spent understanding the
template, tutorial and course.

# Contributions

Marius Lhôte (346838): 1/3

Eva Mangano (345375): 1/3

Alonso Coaguila (339718): 1/3
