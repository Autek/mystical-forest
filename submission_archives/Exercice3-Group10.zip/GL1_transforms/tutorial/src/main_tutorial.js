import {createREGL} from "../lib/regljs_2.1.0/regl.module.js"



const canvas_elem = document.getElementsByTagName('canvas')[0]

// Resize canvas to fit the window, but keep it square.
function resize_canvas() {
    const s = Math.min(window.innerHeight, window.innerWidth) - 10;
    canvas_elem.width = s
    canvas_elem.height = s
}
resize_canvas();


const regl = createREGL();

// The pipeline is constructed only once!
const draw_triangle = regl({

    // Vertex attributes - properties of each vertex such as 
    // position, normal, texture coordinates, etc.
    attributes: {
        // 3 vertices with 2 coordinates each
        position: [
            [0.2, -0.2],
            [-0.2, -0.2],
            [0.0, 0.2],
        ],
        
        color: [
            [0., 0., 1.],
            [0., 1., 0,],
            [1., 0., 0.]
        ]
    },

    // Triangles (faces), as triplets of vertex indices
    elements: [
        // [0, 1, 2], // a triangle
        // [3, 2, 1]
        [0, 1, 2]
    ],
    
    // // Uniforms: global data available to the shader
    // uniforms: {
    //     color: regl.prop('color'),
    // },


    /* 
    Vertex shader program
    Given vertex attributes, it calculates the position of the vertex on screen
    and intermediate data ("varying") passed on to the fragment shader
    */
    // vert: `
    // // Vertex attributes, specified in the "attributes" entry of the pipeline
    // attribute vec2 position;
    vert: 
        await (
            await fetch('./src/shaders/tuto.vert.glsl')
        ).text(),
    
    /* 
    Fragment shader program
    Calculates the color of each pixel covered by the mesh.
    The "varying" values are interpolated between the values 
    given by the vertex shader on the vertices of the current triangle.
    */
    frag: 
        await (
            await fetch('./src/shaders/tuto.frag.glsl')
        ).text(),
});

// Function run to draw each frame
regl.frame((frame) => {
    // Reset the canvas to black
    regl.clear({color: [0, 0, 0, 1]});
        
    // Execute the declared pipeline
    draw_triangle();
});