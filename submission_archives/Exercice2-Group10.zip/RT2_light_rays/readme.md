# Solution Description

We tackled the RT2 project by working on multiple steps simultaneously, but ultimately, we completed it step by step. First, we implemented the lighting, followed by the shadows, and finally, the specular component.

Initially, we ran into some issues because we hadn't uploaded the code from the previous lab. Once we resolved that, the rest was straightforward, mainly involving the implementation of the provided mathematical functions and writting some LaTeX.

# Contributions

Eva Mangano (345375): 1/3

Marius Lhôte (346838): 1/3

Alonso Coaguila (339718): 1/3
