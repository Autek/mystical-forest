To compile `theory.md` into `html` simply run `make`. 

You need to install [`pandoc`](https://pandoc.org/installing.html) first.