# Solution Description

TODO: add a brief description (approximately 10 to 20 lines) of how you solved the proposed exercises

# Contributions

Eva Mangano (345375): 1/3

Marius Lhôte (346838): 1/3

Alonso Coaguila (339718): 1/3
